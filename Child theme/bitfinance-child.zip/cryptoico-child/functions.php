<?php
add_action( 'wp_enqueue_scripts', 'cryptibit_enqueue_styles' );
function cryptibit_enqueue_styles() {
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css' );
    wp_enqueue_style( 'cryptibit-parent-style', get_template_directory_uri() . '/style.css', array('bootstrap'));
    wp_enqueue_style( 'cryptibit-child-style', get_stylesheet_directory_uri() . '/style.css', array('bootstrap'));
}
?>
